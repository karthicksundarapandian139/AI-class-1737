40 Separate AI / Python / Prolog Lab Answer PDFs

Each numbered PDF contains its question and corresponding answer/program.

01. Simple Calculator — 01_simple_calculator.pdf
02. Add Two Matrices — 02_add_two_matrices.pdf
03. Transpose a Matrix — 03_transpose_a_matrix.pdf
04. Sort a Sentence in Alphabetical Order — 04_sort_a_sentence_in_alphabetical_order.pdf
05. List Operations — 05_list_operations.pdf
06. List Methods: Add, Append, Extend and Delete — 06_list_methods_add,_append,_extend_and_delete.pdf
07. Different Set Operations — 07_different_set_operations.pdf
08. Calendar for a Given Month and Year — 08_calendar_for_a_given_month_and_year.pdf
09. Remove Punctuation from a String — 09_remove_punctuation_from_a_string.pdf
10. 8-Puzzle Problem using Breadth-First Search — 10_8-puzzle_problem_using_breadth-first_search.pdf
11. 8-Queen Problem using Backtracking — 11_8-queen_problem_using_backtracking.pdf
12. Water Jug Problem using BFS — 12_water_jug_problem_using_bfs.pdf
13. Crypt-Arithmetic: SEND + MORE = MONEY — 13_crypt-arithmetic_send_+_more_=_money.pdf
14. Missionaries and Cannibals Problem using BFS — 14_missionaries_and_cannibals_problem_using_bfs.pdf
15. Vacuum Cleaner Problem — 15_vacuum_cleaner_problem.pdf
16. Breadth-First Search (BFS) — 16_breadth-first_search_(bfs).pdf
17. Depth-First Search (DFS) — 17_depth-first_search_(dfs).pdf
18. Travelling Salesman Problem by Brute Force — 18_travelling_salesman_problem_by_brute_force.pdf
19. A* Search Algorithm — 19_a*_search_algorithm.pdf
20. Map Coloring using Constraint Satisfaction (CSP) — 20_map_coloring_using_constraint_satisfaction_(c.pdf
21. Tic-Tac-Toe Game — 21_tic-tac-toe_game.pdf
22. Minimax Algorithm for Gaming (Tic-Tac-Toe) — 22_minimax_algorithm_for_gaming_(tic-tac-toe).pdf
23. Alpha-Beta Pruning Algorithm for Gaming — 23_alpha-beta_pruning_algorithm_for_gaming.pdf
24. Decision Tree using a Small ID3 Example — 24_decision_tree_using_a_small_id3_example.pdf
25. Feed Forward Neural Network (Simple Example) — 25_feed_forward_neural_network_(simple_example).pdf
26. Prolog: Sum Integers from 1 to N — 26_prolog_sum_integers_from_1_to_n.pdf
27. Prolog: Database with Name and Date of Birth — 27_prolog_database_with_name_and_date_of_birth.pdf
28. Prolog: Student-Teacher-Subject-Code Database — 28_prolog_student-teacher-subject-code_database.pdf
29. Prolog: Planets Database — 29_prolog_planets_database.pdf
30. Prolog: Towers of Hanoi — 30_prolog_towers_of_hanoi.pdf
31. Prolog: Check Whether a Bird Can Fly — 31_prolog_check_whether_a_bird_can_fly.pdf
32. Prolog: Family Tree Relations — 32_prolog_family_tree_relations.pdf
33. Prolog: Diet Suggestion Based on Disease (Educational Demo) — 33_prolog_diet_suggestion_based_on_disease_(educ.pdf
34. Prolog: Monkey and Banana Problem — 34_prolog_monkey_and_banana_problem.pdf
35. Prolog: Fruit and Its Colour using Backtracking — 35_prolog_fruit_and_its_colour_using_backtrackin.pdf
36. Prolog: Best First Search — 36_prolog_best_first_search.pdf
37. Prolog: Medical Diagnosis (Rule-Based Educational Demo) — 37_prolog_medical_diagnosis_(rule-based_educatio.pdf
38. Prolog: Forward Chaining — 38_prolog_forward_chaining.pdf
39. Prolog: Backward Chaining — 39_prolog_backward_chaining.pdf
40. Create a WordPress Web Blog: Anchor Tag, Title Tag, etc. — 40_create_a_wordpress_web_blog_anchor_tag,_title.pdf